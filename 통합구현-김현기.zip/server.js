// express 서버
const express = require('express');
const app = express();
// body-parser
app.use(express.urlencoded({extended:true}));
app.use(express.json());

app.use(express.static(__dirname+'/build'));

// method-override => delete put method 사용할 수 있게 하는 모듈
const methodOverride = require('method-override')
app.use(methodOverride('_method'));

app.set('view engine','ejs');

//mongoDB
const MongoClient = require('mongodb').MongoClient;

let musicDBUrl='mongodb+srv://admin:qwer1234@list.16ipc.mongodb.net/musicDB?retryWrites=true&w=majority';
let musicDB;
MongoClient.connect(musicDBUrl,(err,result)=>{
  if(err) return console.log('db접근 오류');  
  musicDB=result.db('musicDB');

  
  app.listen(8080,()=>{
    console.log('8080Port Open');
    
  })
});


app.get('/',(req,res)=>
{
    res.sendFile(__dirname+'/build/index.html')
});

app.get('/write',(req,res)=>
{
    res.sendFile(__dirname+'/build/index.html')
});

app.get('/playlist',(req,res)=>
{
    res.render('/viwes/playlist.ejs')
});



app.post('/add',(req,res)=>{
    let Title = parseInt(req.body.title);
    let Artist = req.body.artist;  
    // 발행자료 갯수
      
      //todoapp 자료저장
      musicDB.collection('playrist').insertOne({title:Title,artist:Artist},(err,result)=>{
        if(err) return console.log('/add 오류');
        console.log('/add 성공');
  
     res.redirect('/')
    });  
  })