// express 서버
const express = require('express');
const app = express();
// body-parser
app.use(express.urlencoded({extended:true}));
app.use(express.json());

app.use(express.static(__dirname+'/build'));

// method-override => delete put method 사용할 수 있게 하는 모듈
const methodOverride = require('method-override')
app.use(methodOverride('_method'));


//mongoDB
const MongoClient = require('mongodb').MongoClient;

app.set('view engine','ejs');

let musicDBUrl='mongodb+srv://admin:qwer1234@list.16ipc.mongodb.net/musicDB?retryWrites=true&w=majority';
let musicDB;
MongoClient.connect(musicDBUrl,(err,result)=>{
  if(err) return console.log('db접근 오류');  
  musicDB=result.db('musicDB');

  
  app.listen(8080,()=>{
    console.log('8080Port Open');
    
  })
});


app.get('/',(req,res)=>
{
    res.sendFile(__dirname+'/build/index.html')
});

app.get('/write',(req,res)=>
{
    res.sendFile(__dirname+'/build/index.html')
});





app.post('/add',(req,res)=>{
    let Title = req.body.title;
    let Artist = req.body.artist;  
  
     
      musicDB.collection('playrist').insertOne({title:Title,artist:Artist},(err,result)=>{
        if(err) return console.log('/add 오류');
        console.log('/add 성공');
  
        res.redirect('/playlist')
    });  
  })


  app.get('/playlist',(req,res)=>{ //   /playlist 접속하면
    musicDB.collection('playrist').find().toArray((err,result)=>{ //musicDB에서 배열값을 result로 뽑아서
       if(err)  return console.log('자료검색 오류'); // 에러가 나면 자료검색 오류라는 콘솔창 돌려주고
      res.render('playlist.ejs',{musicData:result}); // index.ejs 파일에 musicData에 아까뽑은 rsult를 넣어서 주는데 왜 안넘어가지
     
    });  
  })